### WhatsApp Bug Bot By `𝐵𝛯𝛮 𝐵𝑈𝐺 𝐵𝛩𝑇`
Very powerfull & dangerou WhatsApp Bug 🐛 bot. 
### Bot Features
*⚠️ 1. Bug menu(full crash) 2. Auto status views 3. Auto read chat 4. Auto bio (about) 5. auto recording & typing 6. Always online 7. heroku full antiban 8. Auto block 9. public/private mode ⚠️*


# Heroku deploy setup


   1. - 🎭 `Star` 🌟 this repository.
- If you don't have a GitHub account, [sign up](https://github.com/join) now. [video Tutorial](https://youtu.be/D9ep0hVF8-c?si=Rn0D1E5-VErXKlap)
2.  - [FORK](https://github.com/techgod143/TECH-GOD-BUG-BOT/fork) this repository.
3.   - Click [SCAN](https://replit.com/@DGXeon/Xeon-PairCode?v=1) and pair the code through the "WhatsApp Linked Devices" option in your WhatsApp app.

4.   - If you don't have an account of heroku [create an account now](https://youtu.be/MFA2p4-BviQ?si=PYVzRn6wnpE4_0Im)
5.  - Now watch this tutorial [Video](https://youtu.be/hjjzFlZmRqk) for `Deploy Bot`



## `Heroku` buildpacks
1. buildpack
-     heroku/nodejs
   
2. buildpack
-     https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
3. buildpack

-     https://github.com/clhuang/heroku-buildpack-webp-binaries.git





#  important 👇 for you

<div align="center">
<a href="https://www.instagram.com/techgod143/"><img src="https://readme-typing-svg.demolab.com?font=Ribeye&size=50&pause=1000&color=G0B1&center=true&width=910&height=100&lines=Don't+Forget+To+Subscribe;my+YouTube+Channel;PROGRAM+By+TECH+GOD" alt="Typing SVG" /></a>
  
# YouTube channel link 👇 
   [`More hacks & tutorials`](youtube.com/@techgod143)

# contact to owner 👇    
<a aria-label="Join our chats" href="https://wa.me/917466008456?text=Hi!! `Tech God` Sir, I need Your Help" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/Owner%20Whatsapp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
</p>
<a aria-label="Join our chats" href="(https://whatsapp.com/channel/0029Va9Ufzi8kyyEnEHvOm1h)" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/WhatsApp%20Channel-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
</p>
